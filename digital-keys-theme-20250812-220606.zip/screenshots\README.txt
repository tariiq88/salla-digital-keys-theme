Place screenshots in 'screenshots' folder 
